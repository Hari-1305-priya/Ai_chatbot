import streamlit as st
from src.chatbot import generate_response

st.set_page_config(page_title="AI Chatbot", page_icon="🤖")

st.title("🧠 AI Expert Chatbot")

if "history" not in st.session_state:
    st.session_state.history = []

query = st.text_input("Ask about AI:")

if st.button("Send"):
    if query:
        response = generate_response(query)
        st.session_state.history.append(("You", query))
        st.session_state.history.append(("Bot", response))

# Display chat
for role, msg in st.session_state.history:
    st.write(f"**{role}:** {msg}")