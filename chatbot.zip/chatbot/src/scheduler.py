import schedule
import time
from ingest import build_index

def update_knowledge():
    print("Updating knowledge base...")
    build_index()
    print("Update complete!")

# Run every 6 hours
schedule.every(6).hours.do(update_knowledge)

print("Scheduler running...")

while True:
    schedule.run_pending()
    time.sleep(60)