from src.retriever import search

def generate_response(query):
    results = search(query)

    if not results:
        return "❌ No relevant information found."

    context = " ".join(results)

    return f"""
📌 Based on latest knowledge:

{context}
"""