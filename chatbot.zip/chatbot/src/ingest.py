import os
import json
import faiss
import numpy as np
from embedding import get_embedding

DATA_PATH = "../data/data.txt"
DB_PATH = "../db/"

def chunk_text(text, size=200):
    words = text.split()
    return [" ".join(words[i:i+size]) for i in range(0, len(words), size)]

def load_data():
    with open(DATA_PATH, "r", encoding="utf-8") as f:
        return f.readlines()

def build_index():
    print("Building / Updating Vector DB...")

    documents = []
    vectors = []

    data = load_data()

    for text in data:
        chunks = chunk_text(text)
        for chunk in chunks:
            emb = get_embedding(chunk)
            vectors.append(emb)
            documents.append(chunk)

    vectors = np.array(vectors).astype("float32")

    index = faiss.IndexFlatL2(vectors.shape[1])
    index.add(vectors)

    os.makedirs(DB_PATH, exist_ok=True)

    faiss.write_index(index, DB_PATH + "index.faiss")

    with open(DB_PATH + "docs.json", "w") as f:
        json.dump(documents, f)

    print("Vector DB Updated Successfully!")

if __name__ == "__main__":
    build_index()