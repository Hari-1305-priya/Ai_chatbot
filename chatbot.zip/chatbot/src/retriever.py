import faiss
import numpy as np
import json
from src.embedding import get_embedding

import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_PATH = os.path.join(BASE_DIR, "db")
# Load DB
index = faiss.read_index(os.path.join(DB_PATH, "index.faiss"))

with open(os.path.join(DB_PATH, "docs.json"), "r") as f:
    documents = json.load(f)

def search(query, k=3):
    q_emb = np.array([get_embedding(query)]).astype("float32")
    distances, indices = index.search(q_emb, k)
    return [documents[i] for i in indices[0]]