# Dynamic Knowledge Chatbot

## Overview
A cost-free chatbot that dynamically updates its knowledge base using a scheduled ingestion pipeline.

## Features
- Free embedding model (SentenceTransformers)
- FAISS vector database
- Automatic updates using scheduler
- Streamlit UI

## How to Run

1. Install dependencies:
   pip install -r requirements.txt

2. Build database:
   python src/ingest.py

3. Run chatbot:
   streamlit run app.py

4. Run scheduler (optional):
   python src/scheduler.py